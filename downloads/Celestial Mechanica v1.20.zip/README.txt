
Celestial Mechanica

Windows v1.0
     
Programming, Music & Sound - Roger Hicks (http://rekcahdam.com)
Artwork & Animation - Paul Veer (http://pietepiet.net/)

----------------------------------------------------------------------------------

 Release Notes:
 ---------------

 Joypad support is provided through the third party "JoyToKey" tool. Plug in
 your joypad, run "JoyToKey.exe" in the JoyToKey directory and assign buttons
 for left, right, space and enter. You may need to adjust the sensitivity 
 of your analogue stick.

 A default profile for an XBox 360 joypad is provided.

 Celestial Mechanica is a flash projector, so it saves your game in your system's flash
 cache. Warning: if you clear your flash cache with a tool like CCleaner, it may 
 delete your saved games!

----------------------------------------------------------------------------------

